export const AppConstants = {
    MAX_TEAM_POINTS : 75,
    MAX_PLAYERS : 7,
    NO_BAT : 3,
    NO_ALLR : 2,
    NO_BOWL : 2
}