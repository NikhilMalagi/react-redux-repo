import React from 'react';

const DisplayPlayers = () => {
    return <>PlayerSection</>
}

export default DisplayPlayers;
